package sio.d3.javafx.cybersensi;

import java.sql.Connection;
import java.sql.SQLException;

public class Test_code {
/*
    public static void main(String[] args) {
        // Essayer d'établir une connexion à la base de données
        try (Connection conn = DATA_CONNECTION.getConnection()) {
            // Si la connexion est réussie, vous pouvez faire vos opérations sur la base de données ici
            System.out.println("Connexion réussie à la base de données !");

            // Par exemple, exécuter des requêtes SQL ou autres opérations

        } catch (SQLException e) {
            // Gestion des erreurs de connexion
            System.err.println("Erreur de connexion ou d'exécution de la requête.");
            e.printStackTrace();
        }
    }

 */
}
